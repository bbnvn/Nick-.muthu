let multiplier = 1;
let interval = null;
let running = false;

let crashPoint = 0;
let cashedOut = false;

let x = 20;
let y = 20;

let balance = 1000;
let bet = 0;

// generate crash point
function generateCrashPoint() {
  const r = Math.random();

  if (r < 0.5) return (Math.random() * 1.5 + 1.2);
  if (r < 0.8) return (Math.random() * 3 + 1.5);
  if (r < 0.95) return (Math.random() * 6 + 3);
  return (Math.random() * 15 + 8);
}

function startGame() {
  if (running) return;

  bet = parseFloat(document.getElementById("bet").value);

  if (bet > balance || bet <= 0) {
    alert("Invalid bet");
    return;
  }

  balance -= bet;
  updateBalance();

  running = true;
  cashedOut = false;

  multiplier = 1;
  crashPoint = generateCrashPoint().toFixed(2);

  x = 20;
  y = 20;

  const plane = document.getElementById("plane");
  const display = document.getElementById("multiplier");

  display.innerText = "1.00x";

  interval = setInterval(() => {

    multiplier += 0.02;

    // ✈️ curved flight (parabolic motion)
    x += 2;
    y += Math.sin(multiplier / 2) * 2 + 1.2;

    plane.style.transform = `translate(${x}px, -${y}px)`;

    // ✨ trail effect
    createTrail(x, y);

    display.innerText = multiplier.toFixed(2) + "x";

    if (multiplier >= crashPoint) {
      crashGame();
    }

  }, 80);
}

// trail effect
function createTrail(x, y) {
  const sky = document.getElementById("sky");
  const dot = document.createElement("div");

  dot.style.position = "absolute";
  dot.style.width = "6px";
  dot.style.height = "6px";
  dot.style.background = "#22c55e";
  dot.style.borderRadius = "50%";
  dot.style.left = x + "px";
  dot.style.bottom = y + "px";
  dot.style.opacity = "0.6";

  sky.appendChild(dot);

  setTimeout(() => dot.remove(), 800);
}

function cashOut() {
  if (!running || cashedOut) return;

  cashedOut = true;

  const win = bet * multiplier;
  balance += win;

  updateBalance();

  alert("Cashed out at " + multiplier.toFixed(2) + "x\nWin: $" + win.toFixed(2));

  stopGame();
}

function crashGame() {
  clearInterval(interval);
  interval = null;
  running = false;

  // 💥 crash flash effect
  document.body.style.background = "red";

  setTimeout(() => {
    document.body.style.background = "";
  }, 200);

  document.getElementById("multiplier").innerText =
    "CRASHED at " + crashPoint + "x";
}

function stopGame() {
  clearInterval(interval);
  interval = null;
  running = false;
}

function updateBalance() {
  document.getElementById("balance").innerText = balance.toFixed(2);
}